<?php /* Smarty version 2.6.26, created on 2010-11-18 17:21:37
         compiled from page.foot.tpl */ ?>
﻿</div></td></tr></table><?php if ($this->_tpl_vars['advertising'][3] && $_SERVER['SCRIPT_NAME'] == '/index.php'): ?><?php $this->assign('adv_title', ($this->_tpl_vars['advertising'][3])); ?><!-- start inc.rekl.foot.tpl  --><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "inc.rekl.foot.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?><!-- end inc.rekl.foot.tpl  --><?php elseif ($this->_tpl_vars['advertising'][4] && $_SERVER['SCRIPT_NAME'] != '/index.php'): ?><?php $this->assign('adv_title', ($this->_tpl_vars['advertising'][4])); ?><!-- start inc.rekl.foot.tpl  --><?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "inc.rekl.foot.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?><!-- end inc.rekl.foot.tpl  --><?php endif; ?><!-- низ страницы --><table class='foot'><tr><td><a href='/users.php'>Зарегистрированно: <?php echo $this->_tpl_vars['count_users']; ?>
</a></td><td><a href='/online.php'>Сейчас на сайте: <?php echo $this->_tpl_vars['count_users_online']; ?>
</a></td><td><a href='/online_g.php'>Гостей на сайте: <?php echo $this->_tpl_vars['count_guest']; ?>
</a></td><td>Генерация страницы: <?php echo $this->_tpl_vars['time_gen']; ?>
 сек</td></tr></table></body></html>