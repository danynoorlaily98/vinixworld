<?php /* Smarty version 2.6.26, created on 2010-04-03 10:00:14
         compiled from inc.aut.tpl */ ?>
<div class="aut">
<?php require_once(SMARTY_CORE_DIR . 'core.smarty_include_php.php');
smarty_core_smarty_include_php(array('smarty_file' => ($this->_tpl_vars['theme_path'])."/php/inc.aut.php", 'smarty_assign' => '', 'smarty_once' => false, 'smarty_include_vars' => array()), $this); ?>
 </div>