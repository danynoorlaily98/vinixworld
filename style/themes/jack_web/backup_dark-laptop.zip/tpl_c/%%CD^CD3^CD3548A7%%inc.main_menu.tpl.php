<?php /* Smarty version 2.6.26, created on 2010-11-18 17:21:32
         compiled from inc.main_menu.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.smarty_include_php.php');
smarty_core_smarty_include_php(array('smarty_file' => ($this->_tpl_vars['theme_path'])."/php/inc.main_menu.php", 'smarty_assign' => '', 'smarty_once' => false, 'smarty_include_vars' => array()), $this); ?>