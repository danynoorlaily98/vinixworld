<?php /* Smarty version 2.6.26, created on 2010-04-05 04:56:05
         compiled from inc.index.block.tpl */ ?>
<div class='index_block'>
<div class='index_block_title'>
<?php echo $this->_tpl_vars['title']; ?>

</div>
<div class='index_block_content'>
<?php echo $this->_tpl_vars['content']; ?>

</div>
</div>