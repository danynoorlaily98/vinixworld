<?php /* Smarty version 2.6.26, created on 2010-09-15 03:15:20
         compiled from inc.title.tpl */ ?>
<div id="wrap_top"><div id="logo"><a href="/">Yor site</a></div></div>