<?
global $user;
if (isset($user)){

echo "<div class='main_menu'><a title='Выход' href='/exit.php?return=".urlencode($_SERVER['REQUEST_URI'])."&amp;$passgen'><img src='/style/themes/".THEME_DIR."/icons/user_exit.gif' alt='' /></a></div>";

echo "<div class='main_menu'><div class='mr1'><b>$user[nick]</b></div></div>";

$smarty = new Smarty_conf();
$menu=array();

$msg=mysql_result(mysql_query("SELECT COUNT(`mail`.`id`) FROM `mail`
 LEFT JOIN `users_konts` ON `mail`.`id_user` = `users_konts`.`id_kont` AND `users_konts`.`id_user` = '$user[id]'
 WHERE `mail`.`id_kont` = '$user[id]' AND (`users_konts`.`type` IS NULL OR `users_konts`.`type` = 'common' OR `users_konts`.`type` = 'favorite') AND `mail`.`read` = '0'"),0);

$msg_f=mysql_result(mysql_query("SELECT COUNT(`mail`.`id`) FROM `mail`
 LEFT JOIN `users_konts` ON `mail`.`id_user` = `users_konts`.`id_kont` AND `users_konts`.`id_user` = '$user[id]'
 WHERE `mail`.`id_kont` = '$user[id]' AND (`users_konts`.`type` = 'favorite') AND `mail`.`read` = '0'"),0);

if ($msg)$menu[]=array('/new_mess.php',($msg_f?'<b>':null).'Нов'.($msg==1?'о':'ы').'е сообщени'.($msg==1?'е':'я').($msg_f?'</b>':null),$msg);


$zakl=mysql_result(mysql_query("SELECT COUNT(`forum_zakl`.`id_them`) FROM `forum_zakl` LEFT JOIN `forum_p` ON `forum_zakl`.`id_them` = `forum_p`.`id_them` AND `forum_p`.`time` > `forum_zakl`.`time` WHERE `forum_zakl`.`id_user` = '$user[id]' AND `forum_p`.`id` IS NOT NULL"),0);

if ($zakl)$menu[]=array('/zakl.php','Сообщения в закладках',$zakl);

include H.'sys/inc/umenu.php';

$smarty->assign('menu',$menu);
$smarty->display('inc.umenu.tpl');

}
else
{
$smarty = new Smarty_conf();
$smarty->assign('form_title','Авторизация');
$smarty->assign('method','POST');
$smarty->assign('action',"/input.php?return=".urlencode($_SERVER['REQUEST_URI'])."&amp;$passgen");
$elements=array();
$elements[]=array('type'=>'input_text', 'title' => 'Логин', 'br'=>1, 'info'=>array('name' => 'nick'));
$elements[]=array('type'=>'password', 'title' => 'Пароль (<a href="/pass.php">забыли</a>)', 'br'=>1, 'info'=>array('name' => 'pass'));
$elements[]=array('type'=>'checkbox', 'br'=>1, 'info'=>array('value'=>1,'checked'=>1, 'name'=>'aut_save', 'text'=>'Запомнить меня'));
$elements[]=array('type'=>'submit', 'br'=>1, 'info'=>array('value'=>'Авторизация')); // кнопка
$elements[]=array('type'=>'text', 'br'=>1, 'value'=>'<a href="/reg.php">Регистрация</a>');
$smarty->assign('el',$elements);
$smarty->display('input.form.tpl');

}
?>